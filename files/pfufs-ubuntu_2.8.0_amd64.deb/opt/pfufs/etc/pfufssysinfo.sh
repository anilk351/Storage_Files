#!/bin/sh

LOGFILENAME=pfufssysinfo.txt
LOGPATH=/var/log/pfufs
WORKFOLDER=$(pwd)
CURRENTDATE=`date -d "today" +"%Y%m%d_%H%M%S"`
FileName=pfufslog${CURRENTDATE}.tar.gz

JudgeOperatingSystem()
{
    JUDGEOSNAME=$1
    JUDGETYPE=$2
    if [ "x$JUDGETYPE" = "xCommand" ]; then
        if [ "x$JUDGEOSNAME" = "xDebian" ]; then
            OSNAME="Debian"
        elif [ "x$JUDGEOSNAME" = "xUbuntu" ]; then
            OSNAME="Ubuntu"
        elif [ "x$JUDGEOSNAME" = "xPardus" ]; then
            OSNAME="Pardus"
        elif [ "x$JUDGEOSNAME" = "xUos" ]; then
            OSNAME="Uos"
        fi
    fi
}
OSNAME=""  
LSBRELEASE=`which lsb_release 2>> /dev/null`
if [ "$LSBRELEASE" != "" ]; then
    # use lsb_release to get os information.
    JudgeOperatingSystem `lsb_release -i | sed 's/Distributor ID: *	*//gI'` "Command"
fi

DoCollectSystemLog()
{
    if [ -f $LOGFILENAME ]; then
        rm $LOGFILENAME 2>/dev/null
    fi
    echo "----- system information -----" >>$LOGFILENAME
    date >> $LOGFILENAME
    uname -a >> $LOGFILENAME
    if [ -f /etc/lsb-release ]; then
        cat /etc/lsb-release >> $LOGFILENAME 2>&1
    fi
    echo "----- cpu and memory information -----" >>$LOGFILENAME
    cat /proc/cpuinfo >> $LOGFILENAME 2>&1
    cat /proc/meminfo >> $LOGFILENAME 2>&1
    echo "----- usb device information -----" >>$LOGFILENAME
    lsusb >> $LOGFILENAME 2>&1
    lsusb -v >> $LOGFILENAME 2>&1
    echo "----- pci information -----" >>$LOGFILENAME
    lspci >> $LOGFILENAME 2>&1
    if [ "$OSNAME" != "" ]; then
        if [ "$OSNAME" != "Uos" ]; then
            echo "----- dmesg information -----" >>$LOGFILENAME
            dmesg >> $LOGFILENAME 2>&1
            echo "----- syslog information -----" >>$LOGFILENAME
            cat /var/log/syslog >> $LOGFILENAME 2>&1
        fi
    fi
    echo "----- file information -----" >>$LOGFILENAME
    lsof /dev >> $LOGFILENAME 2>&1
}

DoZip()
{
    if [ -d $LOGPATH ]; then
        cp $LOGFILENAME $LOGPATH 2>/dev/null
        cd $LOGPATH 2>/dev/null
        tar -czf  $WORKFOLDER/$FileName * 2>/dev/null || {
            echo "It is failed to collect logs." > /dev/tty
            kill -15 $$
        }
        if [ -f ./$LOGFILENAME ]; then
            rm -f ./$LOGFILENAME 2>/dev/null
        fi
        cd $WORKFOLDER 2>/dev/null
    else
        tar -czf  $FileName $LOGFILENAME 2>/dev/null || {
            echo "It is failed to collect logs." > /dev/tty
            kill -15 $$
        }
    fi
}

DoCollectLog()
{
    DoCollectSystemLog&

    COLLECTLOGPID=$!

    while true
    do
        ps -p ${COLLECTLOGPID} > /dev/null
        if [ $? -eq 0 ]; then
            printf "."
            sleep 1
        else
            break
        fi
    done

    if ( DoZip | ( while read a; do printf "."; done; echo; ) ); then
        echo "It is successful to collect logs."
    fi
}


if [ "$OSNAME" != "" ]; then
    if [ "$OSNAME" = "Uos" ]; then
        DoCollectLog
    else
        if [ `id -u` -eq 0 ]; then
            DoCollectLog
        else
            echo "Permission denied."
        fi
    fi
fi