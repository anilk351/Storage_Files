------------------------------------------------------------------------
fi Series
Image scanner driver for Linux 2.8.0
README file
------------------------------------------------------------------------
Copyright PFU Limited 2017-2023


This file includes important notes on this product and also the additional information.

------------------------------------------------------------------------
Table of Contents
------------------------------------------------------------------------
1. Use in High-Safety Applications
2. Copies
3. System Requirements
4. Notes on Scanning
5. Notes on Scan Settings


---------------------------------------------------
1. Use in High-Safety Applications
---------------------------------------------------

This product has been designed and manufactured on the assumption that it will be used in office, personal, domestic, regular industrial, and general-purpose applications.
It has not been designed and manufactured for use in applications (simply called "high-safety applications" from here on) that directly involve danger to life and health when a high degree of safety is required, for example, in the control of nuclear reactions at nuclear power facilities, automatic flight control of aircraft, air traffic control, operation control in mass-transport systems, medical equipment for sustaining life, and missile firing control in weapons systems, and when provisionally the safety in question is not ensured.
The user should use this product with adopting measures for ensuring safety in such high-safety applications. PFU Limited assumes no liability whatsoever for damages arising from use of this product by the user in high-safety applications, and for any claims or compensation for damages by the user or a third party.


---------------------------------------------------
2. Copies
---------------------------------------------------

- Scanning paper currencies, negotiable instruments or official documents with a scanner, printing them out with a printer and using their unauthorized copy is a violation of the law regardless of their printed matter, and you will be subject to punishment.

- Making a copy of creative works such as newspapers, magazines, books which are subject to copyright protection, without permission of the right holder, except the reproduction for personal use, for private use at home or equivalent purpose within the limited range, is prohibited by law. Use the data scanned with a scanner within the range of private use.


---------------------------------------------------
3. System Requirements
---------------------------------------------------

- CPU
  Intel(R) or Intel(R) compatible processor (64bit)


---------------------------------------------------
4. Notes on Scanning
---------------------------------------------------

- Do not let your computer enter standby mode during scanning. Otherwise, scanning may fail due to the "Error during device I/O" error and so on.

- Do not unplug the power cable or interface cable during scanning. Otherwise, scanning may fail due to the "Error during device I/O" error and so on. In that case, connect the USB cable again and power on the scanner to make the computer recognize the scanner.

- Do not log off your computer during scanning. Otherwise, scanning may fail due to the "Error during device I/O" error and so on.

- Do not stop an application with the job control function ("Ctrl+z") during scanning. When you resume the application, it may not operate properly, outputting an error such as "Error during drive I/O". In such a case, exit the application.

- The Ubuntu system already has the sane-fujitsu (SANE backend) driver for fi Series installed on it. If you install this driver, the sane-fujitsu driver becomes unusable in order to avoid a conflict with this driver. Uninstall this driver when you need to use the sane-fujitsu driver again. To view the details about the sane-fujitsu driver, execute "man sane-fujitsu".
 Note that, when using xsane, you need to delete the old configuration file that is created by xsane every time you switch drivers. Perform the following operation.
         rm -f ~/.sane/xsane/FUJITSU*


---------------------------------------------------
5. Notes on Scan Settings
---------------------------------------------------

Notes on the following scanning options are described.

(1) autofeed
  A preceding scan is performed by using the cache memory in the scanner. Because all sheets that are loaded in the feeder are fed, if an application stops the scanning process along the way, the scanned images that remain in the cache memory are discarded. By default, this option is set to "yes". To scan one sheet per scan, set this option to "no".

(2) page-auto
  - When the crop function is used, the function to specify the scanning area cannot be used.
    Options -l, -t, -x, -y are ignored.
  - When the crop function is not used, up to 2600 mm can be specified for the -t (Top-left y) option for the model except the following:
    fi-7460/fi-7480/fi-7700S/fi-800R
  - When paper larger than the specified paper size is scanned, the crop function is not available.


------------------------------------------------------------------------
The following component is used in this product:

 - libjpeg-turbo
  This software is based in part on the work of the Independent JPEG Group.
  
------------------------------------------------------------------------
- Linux(R) is the registered trademark or trademark of Linus Torvalds in the U.S. and other countries.
- Intel and Intel Core are registered trademarks or trademarks of Intel Corporation in the United States and other countries.
- Other company name and product name are trademarks or registered trademarks of individual companies
